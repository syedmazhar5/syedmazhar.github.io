function submitForm() {
  alert("Thanks for reaching out! Your message has been sent.");
  return false;
}

